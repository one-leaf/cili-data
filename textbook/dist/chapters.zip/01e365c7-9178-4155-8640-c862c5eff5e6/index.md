# （根据2022年版课程标准修订）义务教育教科书•数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 数学与我们同行（3297 字）
- [chapters/002.md](chapters/002.md) 有理数（41625 字）
- [chapters/003.md](chapters/003.md) 代数式（19681 字）
- [chapters/004.md](chapters/004.md) 一元一次方程（19414 字）
- [chapters/005.md](chapters/005.md) 走进几何世界（3562 字）
- [chapters/006.md](chapters/006.md) 平面图形的初步认识（23957 字）
