# （根据2022年版课程标准修订）义务教育教科书·生物学七年级下册

教材信息: 初中·生物学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第三单元 人体的结构与功能（24164 字）
- [chapters/002.md](chapters/002.md) 第一章 消化系统与营养摄取（12071 字）
- [chapters/003.md](chapters/003.md) 第二章 循环系统与物质运输（11947 字）
- [chapters/004.md](chapters/004.md) 第三章 呼吸系统与气体交换（7514 字）
- [chapters/005.md](chapters/005.md) 第四章 泌尿系统与废物排出（6722 字）
- [chapters/006.md](chapters/006.md) 第五章 人体生命活动的调节（14942 字）
