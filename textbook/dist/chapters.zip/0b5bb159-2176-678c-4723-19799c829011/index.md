# （根据2022年版课程标准修订）义务教育教科书 英语 七年级上册

教材信息: 初中·英语·七年级·上册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Starter（14921 字）
- [chapters/002.md](chapters/002.md) Unit 1 Family（24994 字）
- [chapters/003.md](chapters/003.md) Unit 2 School Life（25258 字）
- [chapters/004.md](chapters/004.md) Unit 3 Home and Places（26140 字）
- [chapters/005.md](chapters/005.md) Unit 4 Interests and Abilities（25684 字）
