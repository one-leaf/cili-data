# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 一元一次不等式和一元一次不等式组（20625 字）
- [chapters/002.md](chapters/002.md) 二元一次方程组（29489 字）
- [chapters/003.md](chapters/003.md) 整式的运算（38459 字）
- [chapters/004.md](chapters/004.md) 概念、命题与证明（29543 字）
- [chapters/005.md](chapters/005.md) 因式分解（13897 字）
- [chapters/006.md](chapters/006.md) 数据的收集与描述（22428 字）
