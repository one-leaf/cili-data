# 盲校义务教育实验教科书 英语 七年级 上册（供低视力学生使用）

教材信息: 初中·英语·七年级·上册
章节数: 8（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Unit 1 My name's David.（6053 字）
- [chapters/002.md](chapters/002.md) Unit 2 Do you like playing basketball?（7196 字）
- [chapters/003.md](chapters/003.md) Unit 3 When is your birthday?（6807 字）
- [chapters/004.md](chapters/004.md) Unit 4 Where is the key?（6073 字）
- [chapters/005.md](chapters/005.md) Unit 5 How much is this T-shirt?（6506 字）
- [chapters/006.md](chapters/006.md) Unit 6 Can you play Chinese chess?（6848 字）
- [chapters/007.md](chapters/007.md) Unit 7 What time do you go to school?（6841 字）
- [chapters/008.md](chapters/008.md) Unit 8 My favourite subject is history.（6450 字）
