# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1章 相交线与平行线（22356 字）
- [chapters/002.md](chapters/002.md) 第2章 二元一次方程组（23338 字）
- [chapters/003.md](chapters/003.md) 第3章 整式的乘除（32897 字）
- [chapters/004.md](chapters/004.md) 第4章 因式分解（12072 字）
- [chapters/005.md](chapters/005.md) 第5章 分式（21811 字）
- [chapters/006.md](chapters/006.md) 第6章 数据与统计图表（27489 字）
