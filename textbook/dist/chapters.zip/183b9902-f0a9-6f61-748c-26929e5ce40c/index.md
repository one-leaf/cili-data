# （根据2022年版课程标准修订）义务教育教科书 英语 七年级上册

教材信息: 初中·英语·七年级·上册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Unit 1 Let's Be Friends!（19625 字）
- [chapters/002.md](chapters/002.md) Unit 2 Meet My Family!（19064 字）
- [chapters/003.md](chapters/003.md) Unit 3 Our Colorful School Life（20791 字）
- [chapters/004.md](chapters/004.md) Unit 4 Fun in the Sun!（20262 字）
- [chapters/005.md](chapters/005.md) Unit 5 Love Mother Nature!（21230 字）
- [chapters/006.md](chapters/006.md) Unit 6 Celebrating the Big Days（21626 字）
- [chapters/007.md](chapters/007.md) Appendices 附录（27614 字）
