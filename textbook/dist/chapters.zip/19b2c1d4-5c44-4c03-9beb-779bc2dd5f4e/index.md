# （根据2022年版课程标准修订）义务教育教科书·生物学七年级下册

教材信息: 初中·生物学·七年级·下册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第7章 藻类与植物类群（7880 字）
- [chapters/002.md](chapters/002.md) 第8章 动物的主要类群（12184 字）
- [chapters/003.md](chapters/003.md) 第9章 微生物（9954 字）
- [chapters/004.md](chapters/004.md) 第10章 保护生物多样性（6491 字）
- [chapters/005.md](chapters/005.md) 第5单元 植物的生活（11678 字）
- [chapters/006.md](chapters/006.md) 第11章 植物的生命周期（11546 字）
- [chapters/007.md](chapters/007.md) 第12章 植物维持生物圈的稳定（12133 字）
