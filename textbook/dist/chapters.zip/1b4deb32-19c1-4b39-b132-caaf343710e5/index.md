# （根据2022年版课程标准修订）义务教育教科书·地理七年级下册

教材信息: 初中·地理·七年级·下册
章节数: 3（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 认识大洲（13306 字）
- [chapters/002.md](chapters/002.md) 了解地区（15620 字）
- [chapters/003.md](chapters/003.md) 走近国家（17789 字）
