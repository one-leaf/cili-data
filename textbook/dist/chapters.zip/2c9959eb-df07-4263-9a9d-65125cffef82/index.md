# （根据2022年版课程标准修订）义务教育教科书•地理七年级下册

教材信息: 初中·地理·七年级·下册
章节数: 4（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第六章 世界第一大洲——亚洲（5756 字）
- [chapters/002.md](chapters/002.md) 第七章 认识地区（13246 字）
- [chapters/003.md](chapters/003.md) 第八章 认识国家（15810 字）
- [chapters/004.md](chapters/004.md) 第九章 人类命运共同体（6234 字）
