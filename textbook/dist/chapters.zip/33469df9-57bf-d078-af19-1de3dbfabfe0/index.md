# （根据2022年版课程标准修订）义务教育教科书·英语 七年级 下册

教材信息: 初中·英语·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Unit 1 Every Day（30056 字）
- [chapters/002.md](chapters/002.md) Unit 2 Food and Health（28658 字）
- [chapters/003.md](chapters/003.md) Unit 3 Rain or Shine（31467 字）
- [chapters/004.md](chapters/004.md) Unit 4 Landmarks（30980 字）
- [chapters/005.md](chapters/005.md) Unit 5 Now and Then（31916 字）
- [chapters/006.md](chapters/006.md) Unit 6 Animals（35845 字）
