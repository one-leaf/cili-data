# （根据2022年版课程标准修订）义务教育教科书•生物学七年级上册

教材信息: 初中·生物学·七年级·上册
章节数: 4（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1单元 探索生命奥秘（8825 字）
- [chapters/002.md](chapters/002.md) 第2单元 生物体的结构（19079 字）
- [chapters/003.md](chapters/003.md) 第3单元 植物的生活（26289 字）
- [chapters/004.md](chapters/004.md) 跨学科实践活动（5202 字）
