# （根据2022年版课程标准修订）义务教育教科书·英语 七年级上册

教材信息: 初中·英语·七年级·上册
章节数: 8（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Unit 1 School life（39218 字）
- [chapters/002.md](chapters/002.md) Unit 2 Making friends（25721 字）
- [chapters/003.md](chapters/003.md) Unit 3 Be healthy, be happy（19023 字）
- [chapters/004.md](chapters/004.md) Unit 4 Ready, steady, go（20223 字）
- [chapters/005.md](chapters/005.md) Unit 5 Go sightseeing（19427 字）
- [chapters/006.md](chapters/006.md) Unit 6 Inventors and their inventions（23814 字）
- [chapters/007.md](chapters/007.md) Unit 7 Global warming（20691 字）
- [chapters/008.md](chapters/008.md) Unit 8 Holidays and festivals（20615 字）
