# （根据2022年版课程标准修订）义务教育教科书 英语七年级上册

教材信息: 初中·英语·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一单元 Let's Be Friends!（16185 字）
- [chapters/002.md](chapters/002.md) 第二单元 Meet My Family!（16061 字）
- [chapters/003.md](chapters/003.md) 第三单元 Our Colorful School Life!（17491 字）
- [chapters/004.md](chapters/004.md) 第四单元 Fun in the Sun!（17892 字）
- [chapters/005.md](chapters/005.md) 第五单元 Love Mother Nature!（18773 字）
- [chapters/006.md](chapters/006.md) 第六单元 Celebrating the Big Days（19462 字）
