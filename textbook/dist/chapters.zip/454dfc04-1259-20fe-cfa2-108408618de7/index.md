# （根据2022年版课程标准修订）义务教育教科书 英语 七年级 上册

教材信息: 初中·英语·七年级·上册
章节数: 8（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Unit 1 Friendship（15609 字）
- [chapters/002.md](chapters/002.md) Unit 2 School life（16235 字）
- [chapters/003.md](chapters/003.md) Unit 3 The seasons（16876 字）
- [chapters/004.md](chapters/004.md) Unit 4 The Earth（15698 字）
- [chapters/005.md](chapters/005.md) Unit 5 Off to space（18056 字）
- [chapters/006.md](chapters/006.md) Unit 6 Travelling around Asia（18171 字）
- [chapters/007.md](chapters/007.md) Unit 7 Fun after school（16369 字）
- [chapters/008.md](chapters/008.md) Unit 8 Collecting as a hobby（19556 字）
