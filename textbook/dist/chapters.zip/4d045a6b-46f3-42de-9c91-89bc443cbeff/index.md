# （根据2022年版课程标准修订）义务教育教科书·地理七年级上册

教材信息: 初中·地理·七年级·上册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 与同学们谈地理——地理第一课（2120 字）
- [chapters/002.md](chapters/002.md) 第一章 地球（8085 字）
- [chapters/003.md](chapters/003.md) 第二章 地图（5766 字）
- [chapters/004.md](chapters/004.md) 第三章 陆地和海洋（6817 字）
- [chapters/005.md](chapters/005.md) 第四章 天气与气候（9230 字）
- [chapters/006.md](chapters/006.md) 第五章 居民与文化（6762 字）
- [chapters/007.md](chapters/007.md) 第六章 发展与合作（4274 字）
