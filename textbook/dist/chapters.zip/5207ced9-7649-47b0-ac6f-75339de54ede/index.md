# （根据2022年版课程标准修订）义务教育教科书·科学七年级下册

教材信息: 初中·科学·七年级·下册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 运动和静止（8352 字）
- [chapters/002.md](chapters/002.md) 阴晴冷暖（15746 字）
- [chapters/003.md](chapters/003.md) 地月运动（9591 字）
- [chapters/004.md](chapters/004.md) 动物的行为（10251 字）
- [chapters/005.md](chapters/005.md) 物质的变化（13781 字）
- [chapters/006.md](chapters/006.md) 物质的性质（11644 字）
- [chapters/007.md](chapters/007.md) 材料天地（13928 字）
