# （根据2022年版课程标准修订）义务教育教科书·数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一章 有理数（16669 字）
- [chapters/002.md](chapters/002.md) 第二章 有理数的运算（38090 字）
- [chapters/003.md](chapters/003.md) 第三章 代数式（16313 字）
- [chapters/004.md](chapters/004.md) 第四章 整式的加减（18172 字）
- [chapters/005.md](chapters/005.md) 第五章 一元一次方程（29196 字）
- [chapters/006.md](chapters/006.md) 第六章 几何图形初步（22032 字）
