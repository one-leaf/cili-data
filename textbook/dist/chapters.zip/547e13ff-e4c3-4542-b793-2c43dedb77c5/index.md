# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一章 整式的乘除（28427 字）
- [chapters/002.md](chapters/002.md) 第二章 相交线与平行线（12522 字）
- [chapters/003.md](chapters/003.md) 第三章 概率初步（17451 字）
- [chapters/004.md](chapters/004.md) 第四章 三角形（18793 字）
- [chapters/005.md](chapters/005.md) 第五章 图形的轴对称（10262 字）
- [chapters/006.md](chapters/006.md) 第六章 变量之间的关系（13498 字）
- [chapters/007.md](chapters/007.md) 综合与实践（2202 字）
