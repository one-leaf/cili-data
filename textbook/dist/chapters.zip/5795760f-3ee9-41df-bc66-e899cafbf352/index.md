# （根据2022年版课程标准修订）义务教育教科书•地理七年级上册

教材信息: 初中·地理·七年级·上册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 单元一 认识地球探宇宙（17114 字）
- [chapters/002.md](chapters/002.md) 单元二 地球运动永不息（7341 字）
- [chapters/003.md](chapters/003.md) 单元三 海陆分布蕴变迁（9442 字）
- [chapters/004.md](chapters/004.md) 单元四 气象万千多绚丽（10296 字）
- [chapters/005.md](chapters/005.md) 单元五 多元文化共发展（9379 字）
