# （根据2022年版课程标准修订）义务教育教科书•地理七年级上册

教材信息: 初中·地理·七年级·上册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一单元 地理工具与地理实践（12636 字）
- [chapters/002.md](chapters/002.md) 第二单元 地球的宇宙环境（5926 字）
- [chapters/003.md](chapters/003.md) 第三单元 地球的运动（6512 字）
- [chapters/004.md](chapters/004.md) 第四单元 自然地理环境（12407 字）
- [chapters/005.md](chapters/005.md) 第五单元 人文地理环境（12309 字）
