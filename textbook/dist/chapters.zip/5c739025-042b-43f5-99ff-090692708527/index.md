# （根据2022年版课程标准修订）义务教育教科书·生物学七年级下册

教材信息: 初中·生物学·七年级·下册
章节数: 8（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第4单元 人体的结构与生理（38012 字）
- [chapters/002.md](chapters/002.md) 第6章 人体的营养（19051 字）
- [chapters/003.md](chapters/003.md) 第7章 人体的物质运输（12715 字）
- [chapters/004.md](chapters/004.md) 第8章 人体的能量供应（8086 字）
- [chapters/005.md](chapters/005.md) 第9章 人体代谢废物的排出（6483 字）
- [chapters/006.md](chapters/006.md) 第10章 人体的自我调节（16298 字）
- [chapters/007.md](chapters/007.md) 第11章 人体的运动（9648 字）
- [chapters/008.md](chapters/008.md) 跨学科实践活动（5639 字）
