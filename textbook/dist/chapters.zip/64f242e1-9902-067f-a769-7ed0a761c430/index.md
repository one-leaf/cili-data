# （根据2022年版课程标准修订）义务教育教科书·英语 七年级上册

教材信息: 初中·英语·七年级·上册
章节数: 10（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Unit 1 This is me!（13060 字）
- [chapters/002.md](chapters/002.md) Unit 2 Hobbies（13875 字）
- [chapters/003.md](chapters/003.md) Unit 3 Welcome to our school!（14422 字）
- [chapters/004.md](chapters/004.md) Unit 4 School days（13156 字）
- [chapters/005.md](chapters/005.md) Project 1 A video about my new school life（2536 字）
- [chapters/006.md](chapters/006.md) Unit 5 A healthy lifestyle（14680 字）
- [chapters/007.md](chapters/007.md) Unit 6 My clothes, my style（14251 字）
- [chapters/008.md](chapters/008.md) Unit 7 Be wise with money（13032 字）
- [chapters/009.md](chapters/009.md) Unit 8 Let's celebrate!（14870 字）
- [chapters/010.md](chapters/010.md) Project 2 A party plan to celebrate New Year（2637 字）
