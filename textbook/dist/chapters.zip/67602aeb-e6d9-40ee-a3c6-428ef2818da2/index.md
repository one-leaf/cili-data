# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第 7章 数据的收集、整理与描述（17824 字）
- [chapters/002.md](chapters/002.md) 第8章 相交线与平行线（14120 字）
- [chapters/003.md](chapters/003.md) 第9章 二元一次方程组（19157 字）
- [chapters/004.md](chapters/004.md) 第 10 章 整式的乘法与除法（29554 字）
- [chapters/005.md](chapters/005.md) 第 11 章 因式分解（13329 字）
- [chapters/006.md](chapters/006.md) 第 12章 平面图形的认识（19082 字）
- [chapters/007.md](chapters/007.md) 综合与实践（2489 字）
