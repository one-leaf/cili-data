# （根据2022年版课程标准修订）义务教育教科书•地理七年级下册（主编：钟作慈）

教材信息: 初中·地理·七年级·下册
章节数: 4（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第六章 认识大洲（9195 字）
- [chapters/002.md](chapters/002.md) 第七章 认识地区（15659 字）
- [chapters/003.md](chapters/003.md) 第八章 认识国家（17006 字）
- [chapters/004.md](chapters/004.md) 第九章 共建人类地球家园（6452 字）
