# 盲校义务教育实验教科书 数学 七年级 上册（供低视力学生使用）

教材信息: 初中·数学·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一章 有理数（17365 字）
- [chapters/002.md](chapters/002.md) 第二章 有理数的运算（32514 字）
- [chapters/003.md](chapters/003.md) 第三章 整式的加减（17756 字）
- [chapters/004.md](chapters/004.md) 第四章 一元一次方程（19734 字）
- [chapters/005.md](chapters/005.md) 第五章 几何图形（7992 字）
- [chapters/006.md](chapters/006.md) 第六章 线段和角（12286 字）
