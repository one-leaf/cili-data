# （根据2022年版课程标准修订）义务教育教科书·数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第 1 章 有理数（37692 字）
- [chapters/002.md](chapters/002.md) 第 2 章 有理数的运算（44362 字）
- [chapters/003.md](chapters/003.md) 第 3 章 代数式（27938 字）
- [chapters/004.md](chapters/004.md) 第 4 章 整式的加法与减法（13993 字）
- [chapters/005.md](chapters/005.md) 第 5 章 一元一次方程（19078 字）
- [chapters/006.md](chapters/006.md) 第 6 章 基本的几何图形（20174 字）
- [chapters/007.md](chapters/007.md) 综合与实践（3238 字）
