# （根据2022年版课程标准修订）义务教育教科书•地理七年级上册（主编：钟作慈）

教材信息: 初中·地理·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 绪论 我们共同学地理（2684 字）
- [chapters/002.md](chapters/002.md) 第一章 认识地球（12025 字）
- [chapters/003.md](chapters/003.md) 第二章 学用地图（4743 字）
- [chapters/004.md](chapters/004.md) 第三章 认识海洋和陆地（6557 字）
- [chapters/005.md](chapters/005.md) 第四章 认识天气与气候（9558 字）
- [chapters/006.md](chapters/006.md) 第五章 认识人文环境（7940 字）
