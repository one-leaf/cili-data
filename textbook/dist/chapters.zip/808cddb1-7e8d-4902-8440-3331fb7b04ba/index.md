# （根据2022年版课程标准修订）义务教育教科书•地理七年级上册（主编：王民）

教材信息: 初中·地理·七年级·上册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1章 地球的宇宙环境（6989 字）
- [chapters/002.md](chapters/002.md) 第2章 地球和地图（10296 字）
- [chapters/003.md](chapters/003.md) 第3章 中国的疆域和人口（11434 字）
- [chapters/004.md](chapters/004.md) 第4章 中国的自然环境（13096 字）
- [chapters/005.md](chapters/005.md) 跨学科主题学习（3379 字）
