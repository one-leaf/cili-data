# （根据2022年版课程标准修订）义务教育教科书·英语 七年级 下册

教材信息: 初中·英语·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Unit 1 The secrets of happiness（21866 字）
- [chapters/002.md](chapters/002.md) Unit 2 Go for it!（15936 字）
- [chapters/003.md](chapters/003.md) Unit 3 Food matters（16349 字）
- [chapters/004.md](chapters/004.md) Unit 4 The art of having fun（16972 字）
- [chapters/005.md](chapters/005.md) Unit 5 Amazing nature（20101 字）
- [chapters/006.md](chapters/006.md) Unit 6 Hitting the road（16825 字）
