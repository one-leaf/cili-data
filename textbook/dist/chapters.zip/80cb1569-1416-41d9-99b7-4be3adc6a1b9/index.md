# （根据2022年版课程标准修订）义务教育教科书•科学七年级上册

教材信息: 初中·科学·七年级·上册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第 1 章 探索自然的科学（13135 字）
- [chapters/002.md](chapters/002.md) 第 2 章 丰富多彩的生命世界（20315 字）
- [chapters/003.md](chapters/003.md) 第 3 章 广袤浩瀚的宇宙（19545 字）
- [chapters/004.md](chapters/004.md) 第 4 章 多种多样的运动（16853 字）
- [chapters/005.md](chapters/005.md) 第 5 章 探索技术与工程的世界（6133 字）
