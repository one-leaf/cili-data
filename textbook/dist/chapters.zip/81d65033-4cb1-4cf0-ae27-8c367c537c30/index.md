# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 相交线与平行线（24419 字）
- [chapters/002.md](chapters/002.md) 实数（19847 字）
- [chapters/003.md](chapters/003.md) 平面直角坐标系（15245 字）
- [chapters/004.md](chapters/004.md) 二元一次方程组（28092 字）
- [chapters/005.md](chapters/005.md) 不等式与不等式组（23759 字）
- [chapters/006.md](chapters/006.md) 数据的收集、整理与描述（32771 字）
