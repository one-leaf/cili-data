# （根据2022年版课程标准修订）义务教育教科书•数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一章 丰富的图形世界（43513 字）
- [chapters/002.md](chapters/002.md) 第二章 有理数及其运算（39213 字）
- [chapters/003.md](chapters/003.md) 第三章 整式及其加减（42874 字）
- [chapters/004.md](chapters/004.md) 第四章 基本平面图形（20795 字）
- [chapters/005.md](chapters/005.md) 第五章 一元一次方程（22946 字）
- [chapters/006.md](chapters/006.md) 第六章 数据的收集与整理（40711 字）
- [chapters/007.md](chapters/007.md) 综合与实践（3481 字）
