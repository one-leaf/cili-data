# （根据2022年版课程标准修订）义务教育教科书·地理七年级下册

教材信息: 初中·地理·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第六单元 区域位置与特征（11315 字）
- [chapters/002.md](chapters/002.md) 第七单元 区域资源与经济（8957 字）
- [chapters/003.md](chapters/003.md) 第八单元 区域联系与合作（10133 字）
- [chapters/004.md](chapters/004.md) 第九单元 区域可持续发展（8558 字）
- [chapters/005.md](chapters/005.md) 跨学科主题学习1 河流流域开发——以尼罗河为例（1447 字）
- [chapters/006.md](chapters/006.md) 跨学科主题学习2 应对全球环境变化——以应对全球气候变暖为例（1353 字）
