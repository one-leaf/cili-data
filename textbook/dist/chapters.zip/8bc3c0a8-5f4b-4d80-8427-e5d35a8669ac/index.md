# （根据2022年版课程标准修订）义务教育教科书·地理七年级下册

教材信息: 初中·地理·七年级·下册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第七章 我们生活的大洲——亚洲（4563 字）
- [chapters/002.md](chapters/002.md) 第八章 我们邻近的地区和国家（10029 字）
- [chapters/003.md](chapters/003.md) 第九章 东半球其他的地区和国家（9691 字）
- [chapters/004.md](chapters/004.md) 第十章 西半球的国家（6214 字）
- [chapters/005.md](chapters/005.md) 第十一章 极地地区（2771 字）
