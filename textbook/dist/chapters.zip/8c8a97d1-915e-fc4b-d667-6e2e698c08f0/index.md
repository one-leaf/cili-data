# 盲校义务教育实验教科书 信息技术 七年级 下册

教材信息: 初中·信息技术·七年级·下册
章节数: 3（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一章 计算机系统（16527 字）
- [chapters/002.md](chapters/002.md) 第二章 操作系统（7368 字）
- [chapters/003.md](chapters/003.md) 第三章 计算机系统的安全（5029 字）
