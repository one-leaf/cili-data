# （根据2022年版课程标准修订）义务教育教科书•数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1章 有理数（56056 字）
- [chapters/002.md](chapters/002.md) 第2章 有理数的运算（57580 字）
- [chapters/003.md](chapters/003.md) 第3章 实数（44673 字）
- [chapters/004.md](chapters/004.md) 第4章 代数式（26555 字）
- [chapters/005.md](chapters/005.md) 第5章 一元一次方程（37989 字）
- [chapters/006.md](chapters/006.md) 第6章 图形的初步知识（31739 字）
