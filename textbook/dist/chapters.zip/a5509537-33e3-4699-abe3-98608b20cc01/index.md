# （根据2022年版课程标准修订）义务教育教科书•数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 4（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1章 有理数（50565 字）
- [chapters/002.md](chapters/002.md) 第2章 代数式（33703 字）
- [chapters/003.md](chapters/003.md) 第3章 一次方程(组)（42646 字）
- [chapters/004.md](chapters/004.md) 第4章 图形的认识（15500 字）
