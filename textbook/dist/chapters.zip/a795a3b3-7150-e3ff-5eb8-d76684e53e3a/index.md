# （根据2022年版课程标准修订）义务教育教科书 英语 七年级 上册

教材信息: 初中·英语·七年级·上册
章节数: 10（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Starter Unit 1 Hello!（11543 字）
- [chapters/002.md](chapters/002.md) Starter Unit 2 Keep Tidy!（4598 字）
- [chapters/003.md](chapters/003.md) Starter Unit 3 Welcome!（4771 字）
- [chapters/004.md](chapters/004.md) Unit 1 You and Me（8853 字）
- [chapters/005.md](chapters/005.md) Unit 2 We’re Family!（9164 字）
- [chapters/006.md](chapters/006.md) Unit 3 My School（9365 字）
- [chapters/007.md](chapters/007.md) Unit 4 My Favourite Subject（9215 字）
- [chapters/008.md](chapters/008.md) Unit 5 Fun Clubs（9053 字）
- [chapters/009.md](chapters/009.md) Unit 6 A Day in the Life（9640 字）
- [chapters/010.md](chapters/010.md) Unit 7 Happy Birthday!（9983 字）
