# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 实数（15780 字）
- [chapters/002.md](chapters/002.md) 一元一次不等式与不等式组（15539 字）
- [chapters/003.md](chapters/003.md) 整式乘法与因式分解（34627 字）
- [chapters/004.md](chapters/004.md) 分式（22813 字）
- [chapters/005.md](chapters/005.md) 相交线、平行线与平移（15203 字）
