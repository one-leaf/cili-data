# （根据2022年版课程标准修订）义务教育教科书 英语 七年级上册

教材信息: 初中·英语·七年级·上册
章节数: 8（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) Starter Welcome to junior high!（7848 字）
- [chapters/002.md](chapters/002.md) Unit 1 A new start（11258 字）
- [chapters/003.md](chapters/003.md) Unit 2 More than fun（11231 字）
- [chapters/004.md](chapters/004.md) Unit 3 Family ties（12242 字）
- [chapters/005.md](chapters/005.md) Unit 4 Time to celebrate（12771 字）
- [chapters/006.md](chapters/006.md) Unit 5 The power of plants（11725 字）
- [chapters/007.md](chapters/007.md) Unit 6 Fantastic friends（12567 字）
- [chapters/008.md](chapters/008.md) Appendices（33100 字）
