# （根据2022年版课程标准修订）义务教育教科书•地理七年级上册

教材信息: 初中·地理·七年级·上册
章节数: 4（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 主题一 探寻人类的太空家园（7032 字）
- [chapters/002.md](chapters/002.md) 主题二 模拟地球运动（8008 字）
- [chapters/003.md](chapters/003.md) 主题三 探索地球海陆面貌（11159 字）
- [chapters/004.md](chapters/004.md) 主题四 寻找地球上的居住地（11936 字）
