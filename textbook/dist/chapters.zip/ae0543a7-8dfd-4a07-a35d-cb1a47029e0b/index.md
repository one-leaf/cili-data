# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 7（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 一元一次方程（17078 字）
- [chapters/002.md](chapters/002.md) 一次方程组（19717 字）
- [chapters/003.md](chapters/003.md) 一元一次不等式（16756 字）
- [chapters/004.md](chapters/004.md) 三角形（19524 字）
- [chapters/005.md](chapters/005.md) 轴对称、平移与旋转（27760 字）
- [chapters/006.md](chapters/006.md) 项目学习3 体育比赛计分（1653 字）
- [chapters/007.md](chapters/007.md) 项目学习4 生活中的密铺（1739 字）
