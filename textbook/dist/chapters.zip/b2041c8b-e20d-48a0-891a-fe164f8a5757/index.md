# （根据2022年版课程标准修订）义务教育教科书•数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1章 有理数（44766 字）
- [chapters/002.md](chapters/002.md) 第2章 整式及其加减（21056 字）
- [chapters/003.md](chapters/003.md) 第3章 一次方程与方程组（30692 字）
- [chapters/004.md](chapters/004.md) 第4章 几何图形初步（17196 字）
- [chapters/005.md](chapters/005.md) 第5章 数据的收集与整理（18828 字）
