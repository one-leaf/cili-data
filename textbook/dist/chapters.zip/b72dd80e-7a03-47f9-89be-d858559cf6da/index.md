# （根据2022年版课程标准修订）义务教育教科书•科学七年级上册

教材信息: 初中·科学·七年级·上册
章节数: 9（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 走近科学（12766 字）
- [chapters/002.md](chapters/002.md) 第一章 我们的地球（12233 字）
- [chapters/003.md](chapters/003.md) 第二章 变化的地形（10444 字）
- [chapters/004.md](chapters/004.md) 第三章 地球上的生物（6595 字）
- [chapters/005.md](chapters/005.md) 第四章 生物的主要类群（9297 字）
- [chapters/006.md](chapters/006.md) 第五章 生物多样性（8316 字）
- [chapters/007.md](chapters/007.md) 第六章 生物体的结构层次（12273 字）
- [chapters/008.md](chapters/008.md) 第七章 地月系（9364 字）
- [chapters/009.md](chapters/009.md) 第八章 星空世界（9464 字）
