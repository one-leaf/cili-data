# （根据2022年版课程标准修订）义务教育教科书·科学七年级下册

教材信息: 初中·科学·七年级·下册
章节数: 5（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1章 生物的结构与生殖（17584 字）
- [chapters/002.md](chapters/002.md) 第2章 物质的微观结构（20564 字）
- [chapters/003.md](chapters/003.md) 第3章 物质的特性（21278 字）
- [chapters/004.md](chapters/004.md) 第4章 我们生活的大地（17896 字）
- [chapters/005.md](chapters/005.md) 第5章 制造技术与工程（5297 字）
