# （根据2022年版课程标准修订）义务教育教科书•地理七年级上册

教材信息: 初中·地理·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 序言 开启地理之门（1745 字）
- [chapters/002.md](chapters/002.md) 第一章 地球及其宇宙环境（6587 字）
- [chapters/003.md](chapters/003.md) 第二章 地球的运动及其影响（6939 字）
- [chapters/004.md](chapters/004.md) 第三章 地图与地理信息技术（5592 字）
- [chapters/005.md](chapters/005.md) 第四章 地球表层的基础自然要素（12203 字）
- [chapters/006.md](chapters/006.md) 第五章 地球表层的人文环境要素（9114 字）
