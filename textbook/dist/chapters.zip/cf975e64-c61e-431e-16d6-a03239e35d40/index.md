# 盲校义务教育实验教科书 数学 七年级 下册（供低视力学生使用）

教材信息: 初中·数学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第七章 二元一次方程组（16118 字）
- [chapters/002.md](chapters/002.md) 第八章 相交线与平行线（23016 字）
- [chapters/003.md](chapters/003.md) 第九章 平面直角坐标系（11480 字）
- [chapters/004.md](chapters/004.md) 第十章 整式的乘除（23454 字）
- [chapters/005.md](chapters/005.md) 第十一章 数据的收集与整理（8568 字）
- [chapters/006.md](chapters/006.md) 第十二章 数据的描述（14344 字）
