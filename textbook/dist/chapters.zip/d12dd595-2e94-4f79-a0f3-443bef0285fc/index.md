# （根据2022年版课程标准修订）义务教育教科书•地理七年级上册

教材信息: 初中·地理·七年级·上册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第一章 让我们走进地理（12284 字）
- [chapters/002.md](chapters/002.md) 第二章 认识地球（8559 字）
- [chapters/003.md](chapters/003.md) 第三章 地球的面貌（8739 字）
- [chapters/004.md](chapters/004.md) 第四章 世界的居民与文化（8440 字）
- [chapters/005.md](chapters/005.md) 第五章 世界的气候（13305 字）
- [chapters/006.md](chapters/006.md) 第六章 世界的发展差异（6850 字）
