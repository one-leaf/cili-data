# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第1章 整式的乘法（21900 字）
- [chapters/002.md](chapters/002.md) 第2章 实数（20388 字）
- [chapters/003.md](chapters/003.md) 第3章 一元一次不等式（组）（24230 字）
- [chapters/004.md](chapters/004.md) 第4章 平面内的两条直线（11262 字）
- [chapters/005.md](chapters/005.md) 第5章 轴对称与旋转（9597 字）
- [chapters/006.md](chapters/006.md) 第6章 收集、整理与描述数据（11797 字）
