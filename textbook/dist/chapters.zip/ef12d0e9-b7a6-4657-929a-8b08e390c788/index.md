# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第六章 二元一次方程组（19062 字）
- [chapters/002.md](chapters/002.md) 第七章 相交线与平行线（24682 字）
- [chapters/003.md](chapters/003.md) 第八章 整式的乘法（24549 字）
- [chapters/004.md](chapters/004.md) 第九章 因式分解（9909 字）
- [chapters/005.md](chapters/005.md) 第十章 三角形（10584 字）
- [chapters/006.md](chapters/006.md) 第十一章 一元一次不等式和一元一次不等式组（15860 字）
