# （根据2022年版课程标准修订）义务教育教科书·数学七年级下册

教材信息: 初中·数学·七年级·下册
章节数: 6（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 幂的运算（24948 字）
- [chapters/002.md](chapters/002.md) 整式乘法（28277 字）
- [chapters/003.md](chapters/003.md) 图形的变换（32044 字）
- [chapters/004.md](chapters/004.md) 二元一次方程组（27261 字）
- [chapters/005.md](chapters/005.md) 一元一次不等式（32978 字）
- [chapters/006.md](chapters/006.md) 定义 命题 证明（15340 字）
