# （根据2022年版课程标准修订）义务教育教科书•数学七年级上册

教材信息: 初中·数学·七年级·上册
章节数: 4（内容在 chapters/ 子目录，按需加载）

- [chapters/001.md](chapters/001.md) 第 1 章 有理数（50898 字）
- [chapters/002.md](chapters/002.md) 第 2 章 整式及其加减（32540 字）
- [chapters/003.md](chapters/003.md) 第 3 章 图形的初步认识（29209 字）
- [chapters/004.md](chapters/004.md) 第 4 章 相交线和平行线（22125 字）
